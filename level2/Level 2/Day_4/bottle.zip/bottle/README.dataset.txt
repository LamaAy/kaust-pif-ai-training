# bottle > 2022-01-30 3:23pm
https://universe.roboflow.com/sdp2/bottle-f2u4m

Provided by a Roboflow user
License: CC BY 4.0

